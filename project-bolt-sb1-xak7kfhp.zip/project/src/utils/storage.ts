import { Booking, Proposal } from '../types/booking';

const BOOKINGS_KEY = 'band_bookings';
const PROPOSALS_KEY = 'band_proposals';

// Pre-existing bookings that are already confirmed
const PRE_EXISTING_BOOKINGS: Booking[] = [
  {
    id: 'pre-1',
    clientName: 'Festa aniversário d\'Os Lagoias',
    clientEmail: 'contato@oslagoias.pt',
    clientPhone: '912345678',
    eventDate: '2025-07-12',
    eventType: 'Festa de Aniversário',
    venue: 'Portalegre',
    duration: 90,
    guests: 100,
    budget: '2500',
    message: 'Festa de aniversário especial',
    status: 'booked',
    proposalSent: true,
    proposalAmount: 2500,
    createdAt: '2024-01-01T00:00:00.000Z'
  },
  {
    id: 'pre-2',
    clientName: 'Festas em Honra de Nª Srª da Alegria',
    clientEmail: 'festas@alegrete.pt',
    clientPhone: '913456789',
    eventDate: '2025-08-14',
    eventType: 'Festival',
    venue: 'Alegrete',
    duration: 60,
    guests: 500,
    budget: '3000',
    message: 'Festas tradicionais de Alegrete',
    status: 'booked',
    proposalSent: true,
    proposalAmount: 3000,
    createdAt: '2024-01-02T00:00:00.000Z'
  },
  {
    id: 'pre-3',
    clientName: 'Evento Casa Branca',
    clientEmail: 'eventos@casabranca.pt',
    clientPhone: '914567890',
    eventDate: '2025-08-15',
    eventType: 'Celebração Familiar',
    venue: 'Casa Branca (Sousel)',
    duration: 60,
    guests: 80,
    budget: '2000',
    message: 'Celebração especial em Casa Branca',
    status: 'booked',
    proposalSent: true,
    proposalAmount: 2000,
    createdAt: '2024-01-03T00:00:00.000Z'
  },
  {
    id: 'pre-4',
    clientName: 'Carolina Pinheiro',
    clientEmail: 'carolina.pinheiro@email.com',
    clientPhone: '915678901',
    eventDate: '2025-08-16',
    eventType: 'Casamento',
    venue: 'Ervedal Avis',
    duration: 90,
    guests: 120,
    budget: '3500',
    message: 'Casamento da Carolina - evento muito especial',
    status: 'booked',
    proposalSent: true,
    proposalAmount: 3500,
    createdAt: '2024-01-04T00:00:00.000Z'
  }
];

export const storageUtils = {
  getBookings: (): Booking[] => {
    try {
      const stored = localStorage.getItem(BOOKINGS_KEY);
      const allBookings = stored ? JSON.parse(stored) : [];
      
      // If no stored bookings, return pre-existing ones
      if (allBookings.length === 0) {
        return [...PRE_EXISTING_BOOKINGS];
      }
      
      return allBookings;
    } catch (error) {
      console.error('Error loading bookings:', error);
      return [...PRE_EXISTING_BOOKINGS];
    }
  },

  saveBookings: (bookings: Booking[]): void => {
    try {
      localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
    } catch (error) {
      console.error('Error saving bookings:', error);
    }
  },

  addBooking: (booking: Booking): void => {
    try {
      const allBookings = storageUtils.getBookings();
      allBookings.push(booking);
      storageUtils.saveBookings(allBookings);
    } catch (error) {
      console.error('Error adding booking:', error);
    }
  },

  updateBooking: (id: string, updates: Partial<Booking>): void => {
    try {
      const allBookings = storageUtils.getBookings();
      const index = allBookings.findIndex(booking => booking.id === id);
      
      if (index !== -1) {
        // Update the booking with new data
        allBookings[index] = { ...allBookings[index], ...updates };
        storageUtils.saveBookings(allBookings);
        console.log('Booking updated successfully:', id, updates);
      } else {
        console.error('Booking not found for update:', id);
      }
    } catch (error) {
      console.error('Error updating booking:', error);
    }
  },

  getProposals: (): Proposal[] => {
    try {
      const stored = localStorage.getItem(PROPOSALS_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error loading proposals:', error);
      return [];
    }
  },

  saveProposals: (proposals: Proposal[]): void => {
    try {
      localStorage.setItem(PROPOSALS_KEY, JSON.stringify(proposals));
    } catch (error) {
      console.error('Error saving proposals:', error);
    }
  },

  addProposal: (proposal: Proposal): void => {
    try {
      const proposals = storageUtils.getProposals();
      proposals.push(proposal);
      storageUtils.saveProposals(proposals);
    } catch (error) {
      console.error('Error adding proposal:', error);
    }
  },

  isDateBooked: (date: string): boolean => {
    try {
      const bookings = storageUtils.getBookings();
      return bookings.some(booking => 
        booking.eventDate === date && booking.status === 'booked'
      );
    } catch (error) {
      console.error('Error checking date booking:', error);
      return false;
    }
  },

  getBookingsForDate: (date: string): Booking[] => {
    try {
      const bookings = storageUtils.getBookings();
      return bookings.filter(booking => booking.eventDate === date);
    } catch (error) {
      console.error('Error getting bookings for date:', error);
      return [];
    }
  },

  // Initialize storage with pre-existing bookings if empty
  initializeStorage: (): void => {
    try {
      const stored = localStorage.getItem(BOOKINGS_KEY);
      if (!stored) {
        storageUtils.saveBookings([...PRE_EXISTING_BOOKINGS]);
      }
    } catch (error) {
      console.error('Error initializing storage:', error);
    }
  }
};

// Initialize storage on module load
storageUtils.initializeStorage();