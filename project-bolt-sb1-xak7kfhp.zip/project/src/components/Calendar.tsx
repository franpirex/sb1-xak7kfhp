import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, X, Settings, Edit, Heart } from 'lucide-react';
import { Booking } from '../types/booking';
import { storageUtils } from '../utils/storage';

interface CalendarProps {
  viewMode: 'client' | 'admin';
}

const Calendar: React.FC<CalendarProps> = ({ viewMode }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [showAvailableModal, setShowAvailableModal] = useState(false);
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);
  const [editFormData, setEditFormData] = useState({
    clientName: '',
    clientEmail: '',
    clientPhone: '',
    eventType: '',
    venue: '',
    duration: 60,
    budget: '',
    message: ''
  });

  useEffect(() => {
    setBookings(storageUtils.getBookings());
  }, []);

  // Listen for storage changes to sync between admin and client views
  useEffect(() => {
    const handleStorageChange = () => {
      setBookings(storageUtils.getBookings());
    };

    // Listen for custom storage events
    window.addEventListener('bookingsUpdated', handleStorageChange);
    
    // Also listen for storage events from other tabs/windows
    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('bookingsUpdated', handleStorageChange);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const eventTypes = [
    'Casamento',
    'Festa de Aniversário',
    'Evento Corporativo',
    'Festa Privada',
    'Festival',
    'Concerto',
    'Celebração Familiar',
    'Outro'
  ];

  const durationOptions = [
    { value: 45, label: '45 minutos' },
    { value: 60, label: '60 minutos' },
    { value: 90, label: '90 minutos' }
  ];

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const formatDate = (year: number, month: number, day: number) => {
    return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };

  const getBookingStatus = (dateString: string) => {
    const dayBookings = storageUtils.getBookingsForDate(dateString);
    if (dayBookings.length === 0) return null;
    
    const hasBooked = dayBookings.some(b => b.status === 'booked');
    if (hasBooked) return 'booked';
    
    return null;
  };

  const isDateAvailableForBooking = (dateString: string) => {
    const selectedDate = new Date(dateString);
    const today = new Date();
    
    // Set time to start of day for accurate comparison
    today.setHours(0, 0, 0, 0);
    selectedDate.setHours(0, 0, 0, 0);
    
    // Date must be at least tomorrow
    return selectedDate > today;
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const handleDateClick = (dateString: string) => {
    const status = getBookingStatus(dateString);
    
    if (viewMode === 'client') {
      // Only show modal if date is available AND not today/past
      if (!status && isDateAvailableForBooking(dateString)) {
        setSelectedDate(dateString);
        setShowAvailableModal(true);
      }
      // If date is booked or today/past, do nothing for client
    } else {
      // Admin view - show details for any date
      setSelectedDate(dateString);
    }
  };

  const handleEditBooking = (booking: Booking) => {
    setEditingBooking(booking);
    setEditFormData({
      clientName: booking.clientName,
      clientEmail: booking.clientEmail,
      clientPhone: booking.clientPhone,
      eventType: booking.eventType,
      venue: booking.venue,
      duration: booking.duration,
      budget: booking.budget,
      message: booking.message
    });
  };

  const handleSaveEdit = () => {
    if (!editingBooking) return;

    storageUtils.updateBooking(editingBooking.id, editFormData);
    setBookings(storageUtils.getBookings());
    setEditingBooking(null);
    
    // Trigger custom event to notify other components
    window.dispatchEvent(new CustomEvent('bookingsUpdated'));
  };

  const handleDeleteBooking = (bookingId: string) => {
    if (confirm('Tem certeza que deseja eliminar esta reserva?')) {
      const bookings = storageUtils.getBookings();
      const updatedBookings = bookings.filter(b => b.id !== bookingId);
      storageUtils.saveBookings(updatedBookings);
      setBookings(updatedBookings);
      
      // Trigger custom event to notify other components
      window.dispatchEvent(new CustomEvent('bookingsUpdated'));
    }
  };

  const handleInterest = () => {
    setShowAvailableModal(false);
    // Trigger the parent component to change section to booking
    // We'll use a custom event to communicate with the parent App component
    const event = new CustomEvent('navigateToBooking', { 
      detail: { section: 'booking' } 
    });
    window.dispatchEvent(event);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow numbers and limit to 9 digits
    const numericValue = value.replace(/\D/g, '').slice(0, 9);
    setEditFormData(prev => ({ ...prev, clientPhone: numericValue }));
  };

  const renderCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = getDaysInMonth(currentDate);
    const firstDay = getFirstDayOfMonth(currentDate);
    const today = new Date();
    const todayString = formatDate(today.getFullYear(), today.getMonth(), today.getDate());

    const days = [];

    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-12 sm:h-16 md:h-20 lg:h-24"></div>);
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dateString = formatDate(year, month, day);
      const status = getBookingStatus(dateString);
      const isToday = dateString === todayString;
      const isPastOrToday = new Date(dateString) <= today;
      const isAvailableForBooking = isDateAvailableForBooking(dateString);

      days.push(
        <div
          key={day}
          onClick={() => handleDateClick(dateString)}
          className={`h-12 sm:h-16 md:h-20 lg:h-24 border border-amber-200 transition-all duration-300 relative rounded-lg overflow-hidden ${
            status === 'booked' 
              ? 'bg-red-100 border-red-300 cursor-pointer hover:border-red-400' 
              : isToday 
                ? 'bg-yellow-50 border-yellow-400' 
                : isPastOrToday
                  ? 'bg-gray-100 border-gray-300 opacity-60 cursor-not-allowed'
                  : 'bg-white hover:bg-amber-50 cursor-pointer hover:border-yellow-400'
          }`}
        >
          <div className="p-1 sm:p-2 h-full flex flex-col">
            <div className={`text-xs sm:text-sm font-bold ${
              status === 'booked' 
                ? 'text-red-700' 
                : isToday 
                  ? 'text-yellow-600' 
                  : isPastOrToday
                    ? 'text-gray-500'
                    : 'text-black'
            } mb-1 flex-shrink-0`}>
              {day}
            </div>
          </div>
        </div>
      );
    }

    return days;
  };

  const selectedDateBookings = selectedDate ? storageUtils.getBookingsForDate(selectedDate) : [];

  return (
    <div className="min-h-screen bg-amber-50 pt-16 sm:pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        <div className="bg-white shadow-lg rounded-2xl sm:rounded-3xl overflow-hidden border-2 border-yellow-400/20">
          {/* Header */}
          <div className="bg-black px-4 sm:px-6 lg:px-8 py-8 sm:py-12 text-center">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black text-white mb-3 sm:mb-4 tracking-tighter flex items-center justify-center space-x-2 sm:space-x-3">
              <CalendarIcon className="h-6 w-6 sm:h-8 sm:w-8 lg:h-10 lg:w-10" />
              <span>Calendário</span>
            </h2>
            <div className="w-8 sm:w-12 h-1 bg-yellow-400 mx-auto mb-3 sm:mb-4"></div>
            <p className="text-sm sm:text-lg text-yellow-200 font-light">
              {viewMode === 'client' 
                ? 'Verifique a nossa disponibilidade para a data do seu evento'
                : 'Gerir contratações e acompanhar disponibilidade'
              }
            </p>
          </div>

          <div className="p-4 sm:p-6 lg:p-8">
            {/* Calendar Navigation */}
            <div className="flex items-center justify-between mb-6 sm:mb-8">
              <button
                onClick={() => navigateMonth('prev')}
                className="flex items-center space-x-1 sm:space-x-2 px-2 sm:px-4 py-2 border-2 border-amber-200 text-amber-700 rounded-full hover:bg-amber-50 transition-all duration-300 text-xs sm:text-base"
              >
                <ChevronLeft className="h-4 w-4 sm:h-5 sm:w-5" />
                <span className="font-semibold hidden sm:inline">Anterior</span>
              </button>
              
              <h3 className="text-lg sm:text-2xl lg:text-3xl font-black text-black tracking-tight text-center">
                {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h3>
              
              <button
                onClick={() => navigateMonth('next')}
                className="flex items-center space-x-1 sm:space-x-2 px-2 sm:px-4 py-2 border-2 border-amber-200 text-amber-700 rounded-full hover:bg-amber-50 transition-all duration-300 text-xs sm:text-base"
              >
                <span className="font-semibold hidden sm:inline">Próximo</span>
                <ChevronRight className="h-4 w-4 sm:h-5 sm:w-5" />
              </button>
            </div>

            {/* Legend - Simplified */}
            <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-6 mb-6 sm:mb-8 p-3 sm:p-4 bg-amber-50 rounded-xl border border-amber-200">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-white border border-amber-200 rounded"></div>
                <span className="text-xs sm:text-sm font-medium text-amber-700">Disponível</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-red-100 border border-red-300 rounded"></div>
                <span className="text-xs sm:text-sm font-medium text-amber-700">Reservado</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-yellow-50 border border-yellow-400 rounded"></div>
                <span className="text-xs sm:text-sm font-medium text-amber-700">Hoje</span>
              </div>
            </div>

            {/* Calendar Grid */}
            <div className="bg-white border-2 border-amber-100 rounded-xl overflow-hidden">
              {/* Day headers */}
              <div className="grid grid-cols-7 gap-0 border-b-2 border-amber-100">
                {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
                  <div key={day} className="h-8 sm:h-10 flex items-center justify-center text-amber-700 font-bold text-xs sm:text-sm bg-amber-50">
                    {day}
                  </div>
                ))}
              </div>
              
              {/* Calendar days */}
              <div className="grid grid-cols-7 gap-0">
                {renderCalendarDays()}
              </div>
            </div>

            {/* Admin Selected Date Details */}
            {viewMode === 'admin' && selectedDate && (
              <div className="mt-6 sm:mt-8 bg-white border-2 border-amber-100 rounded-xl p-4 sm:p-6">
                <div className="flex items-center justify-between mb-3 sm:mb-4">
                  <h4 className="text-lg sm:text-xl font-black text-black">
                    {new Date(selectedDate).toLocaleDateString('pt-PT', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </h4>
                  <button
                    onClick={() => setSelectedDate(null)}
                    className="p-2 text-amber-500 hover:bg-amber-100 rounded-xl transition-colors duration-300"
                  >
                    <X className="h-4 w-4 sm:h-5 sm:w-5" />
                  </button>
                </div>

                {selectedDateBookings.length > 0 ? (
                  <div className="space-y-3 sm:space-y-4">
                    {selectedDateBookings.map(booking => (
                      <div key={booking.id} className="bg-amber-50 border border-amber-100 rounded-xl p-3 sm:p-4 overflow-hidden">
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between mb-2 sm:mb-3 space-y-2 sm:space-y-0 sm:space-x-3">
                          <div className="min-w-0 flex-1">
                            <h5 className="text-base sm:text-lg font-bold text-black truncate">{booking.clientName}</h5>
                            <div className="flex items-center space-x-2 mt-1">
                              <span className={`inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full whitespace-nowrap ${
                                booking.status === 'booked' ? 'bg-green-100 text-green-800 border border-green-200' :
                                booking.status === 'approved' ? 'bg-blue-100 text-blue-800 border border-blue-200' :
                                booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800 border border-yellow-200' :
                                'bg-gray-100 text-gray-800 border border-gray-200'
                              }`}>
                                {booking.status === 'booked' ? 'Reservado' :
                                 booking.status === 'approved' ? 'Aprovado' :
                                 booking.status === 'pending' ? 'Pendente' :
                                 booking.status}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 flex-shrink-0">
                            <button
                              onClick={() => handleEditBooking(booking)}
                              className="p-1.5 text-amber-500 hover:text-amber-700 hover:bg-amber-100 rounded-lg transition-colors duration-300"
                              title="Editar reserva"
                            >
                              <Settings className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteBooking(booking.id)}
                              className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-100 rounded-lg transition-colors duration-300"
                              title="Eliminar reserva"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                        <div className="text-amber-700 space-y-1 text-xs sm:text-sm">
                          <p className="truncate"><strong>Evento:</strong> {booking.eventType}</p>
                          <p className="truncate"><strong>Local:</strong> {booking.venue}</p>
                          <p><strong>Duração:</strong> {booking.duration} minutos</p>
                          <p className="truncate"><strong>Contacto:</strong> {booking.clientEmail}</p>
                          <p><strong>Telefone:</strong> {booking.clientPhone}</p>
                          <p><strong>Orçamento:</strong> €{booking.budget}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 sm:py-12">
                    <div className="text-4xl sm:text-6xl mb-3 sm:mb-4">📅</div>
                    <p className="text-lg sm:text-xl font-bold text-black mb-2">Nenhuma contratação para esta data</p>
                    <p className="text-amber-600 text-sm sm:text-base">Esta data está disponível para contratação!</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Available Date Modal for Clients */}
        {showAvailableModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white max-w-sm w-full rounded-2xl border-2 border-yellow-400/20 text-center p-6 mx-4">
              <div className="text-4xl sm:text-6xl mb-4">😊</div>
              <h3 className="text-xl font-black text-black mb-3">Esta data parece que está disponível!!</h3>
              <p className="text-amber-700 mb-6 text-sm">
                {selectedDate && new Date(selectedDate).toLocaleDateString('pt-PT', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
              <div className="flex flex-col space-y-3">
                <button
                  onClick={handleInterest}
                  className="px-6 py-3 bg-yellow-400 text-black font-semibold rounded-full hover:bg-yellow-500 transition-all duration-300 text-sm"
                >
                  Tenho interesse
                </button>
                <button
                  onClick={() => setShowAvailableModal(false)}
                  className="px-6 py-3 border-2 border-amber-200 text-amber-700 font-semibold rounded-full hover:bg-amber-50 transition-all duration-300 text-sm"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Edit Booking Modal */}
        {editingBooking && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-2xl border-2 border-yellow-400/20">
              <div className="bg-black px-4 sm:px-6 py-4 sm:py-6 text-center">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <Edit className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                  <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">Editar Reserva</h3>
                </div>
                <p className="text-yellow-200 text-sm">Modificar detalhes da reserva</p>
              </div>
              
              <div className="p-4 sm:p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-black font-semibold text-sm tracking-wide">NOME DO CLIENTE</label>
                    <input
                      type="text"
                      value={editFormData.clientName}
                      onChange={(e) => setEditFormData(prev => ({ ...prev, clientName: e.target.value }))}
                      className="w-full px-3 py-2 border-2 border-amber-200 rounded-xl focus:border-yellow-400 focus:outline-none text-sm"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-black font-semibold text-sm tracking-wide">EMAIL</label>
                    <input
                      type="email"
                      value={editFormData.clientEmail}
                      onChange={(e) => setEditFormData(prev => ({ ...prev, clientEmail: e.target.value }))}
                      className="w-full px-3 py-2 border-2 border-amber-200 rounded-xl focus:border-yellow-400 focus:outline-none text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-black font-semibold text-sm tracking-wide">TELEFONE (9 dígitos)</label>
                    <input
                      type="tel"
                      value={editFormData.clientPhone}
                      onChange={handlePhoneChange}
                      className="w-full px-3 py-2 border-2 border-amber-200 rounded-xl focus:border-yellow-400 focus:outline-none text-sm"
                      placeholder="912345678"
                      maxLength={9}
                    />
                    <p className="text-amber-600 text-xs">Apenas números, máximo 9 dígitos</p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-black font-semibold text-sm tracking-wide">TIPO DE EVENTO</label>
                    <select
                      value={editFormData.eventType}
                      onChange={(e) => setEditFormData(prev => ({ ...prev, eventType: e.target.value }))}
                      className="w-full px-3 py-2 border-2 border-amber-200 rounded-xl focus:border-yellow-400 focus:outline-none text-sm"
                    >
                      {eventTypes.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-black font-semibold text-sm tracking-wide">LOCAL</label>
                    <input
                      type="text"
                      value={editFormData.venue}
                      onChange={(e) => setEditFormData(prev => ({ ...prev, venue: e.target.value }))}
                      className="w-full px-3 py-2 border-2 border-amber-200 rounded-xl focus:border-yellow-400 focus:outline-none text-sm"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-black font-semibold text-sm tracking-wide">DURAÇÃO</label>
                    <select
                      value={editFormData.duration}
                      onChange={(e) => setEditFormData(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                      className="w-full px-3 py-2 border-2 border-amber-200 rounded-xl focus:border-yellow-400 focus:outline-none text-sm"
                    >
                      {durationOptions.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-black font-semibold text-sm tracking-wide">ORÇAMENTO (€)</label>
                  <input
                    type="tel"
                    value={editFormData.budget}
                    onChange={(e) => {
                      const numericValue = e.target.value.replace(/\D/g, '').slice(0, 5);
                      setEditFormData(prev => ({ ...prev, budget: numericValue }));
                    }}
                    className="w-full px-3 py-2 border-2 border-amber-200 rounded-xl focus:border-yellow-400 focus:outline-none text-sm"
                    placeholder="1500"
                    maxLength={5}
                  />
                  <p className="text-amber-600 text-xs">Apenas números, máximo 5 dígitos</p>
                </div>

                <div className="space-y-2">
                  <label className="text-black font-semibold text-sm tracking-wide">NOTAS ADICIONAIS</label>
                  <textarea
                    value={editFormData.message}
                    onChange={(e) => setEditFormData(prev => ({ ...prev, message: e.target.value }))}
                    rows={3}
                    className="w-full px-3 py-2 border-2 border-amber-200 rounded-xl focus:border-yellow-400 focus:outline-none resize-none text-sm"
                  />
                </div>
                
                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 pt-4">
                  <button
                    onClick={handleSaveEdit}
                    className="flex-1 px-4 py-2 bg-yellow-400 text-black font-semibold rounded-full hover:bg-yellow-500 transition-all duration-300 text-sm"
                  >
                    Guardar Alterações
                  </button>
                  <button
                    onClick={() => setEditingBooking(null)}
                    className="flex-1 px-4 py-2 border-2 border-amber-200 text-amber-700 font-semibold rounded-full hover:bg-amber-50 transition-all duration-300 text-sm"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Calendar;