import React, { useState } from 'react';
import { Zap, Menu, X } from 'lucide-react';

interface HeaderProps {
  viewMode: 'client';
  onViewModeChange: () => void;
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const Header: React.FC<HeaderProps> = ({ 
  activeSection, 
  onSectionChange 
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSectionChange = (section: string) => {
    onSectionChange(section);
    setIsMobileMenuOpen(false); // Close mobile menu when navigating
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <>
      <header className="bg-white/95 backdrop-blur-xl border-b border-amber-200 fixed w-full top-0 z-50 transition-all duration-300 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-3 sm:py-4">
            {/* Logo and Brand */}
            <div className="flex items-center space-x-3 sm:space-x-4 flex-shrink-0">
              <div className="bg-yellow-400 p-2 sm:p-2.5 rounded-xl shadow-sm">
                <Zap className="h-4 w-4 sm:h-5 sm:w-5 text-black" />
              </div>
              <div className="min-w-0">
                <h1 className="text-lg sm:text-xl font-semibold text-black tracking-tight truncate">
                  Raio dos Cachopos
                </h1>
                <p className="text-amber-600 text-xs font-medium tracking-wide hidden sm:block">
                  POP TRADICIONAL AGROBETO
                </p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-1">
              <button
                onClick={() => handleSectionChange('home')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  activeSection === 'home'
                    ? 'bg-yellow-400 text-black shadow-sm'
                    : 'text-amber-700 hover:text-black hover:bg-amber-50'
                }`}
              >
                Início
              </button>
              <button
                onClick={() => handleSectionChange('booking')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  activeSection === 'booking'
                    ? 'bg-yellow-400 text-black shadow-sm'
                    : 'text-amber-700 hover:text-black hover:bg-amber-50'
                }`}
              >
                Pedir Orçamento
              </button>
              <button
                onClick={() => handleSectionChange('calendar')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  activeSection === 'calendar'
                    ? 'bg-yellow-400 text-black shadow-sm'
                    : 'text-amber-700 hover:text-black hover:bg-amber-50'
                }`}
              >
                Disponibilidade
              </button>
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={toggleMobileMenu}
              className="md:hidden p-2 rounded-xl text-amber-700 hover:text-black hover:bg-amber-50 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-offset-2"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        <div className={`md:hidden transition-all duration-300 ease-in-out ${
          isMobileMenuOpen 
            ? 'max-h-64 opacity-100 border-t border-amber-200' 
            : 'max-h-0 opacity-0 overflow-hidden'
        }`}>
          <div className="px-4 py-4 space-y-2 bg-white/98 backdrop-blur-xl">
            <button
              onClick={() => handleSectionChange('home')}
              className={`w-full text-left px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 ${
                activeSection === 'home'
                  ? 'bg-yellow-400 text-black shadow-sm'
                  : 'text-amber-700 hover:text-black hover:bg-amber-50'
              }`}
            >
              Início
            </button>
            <button
              onClick={() => handleSectionChange('booking')}
              className={`w-full text-left px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 ${
                activeSection === 'booking'
                  ? 'bg-yellow-400 text-black shadow-sm'
                  : 'text-amber-700 hover:text-black hover:bg-amber-50'
              }`}
            >
              Pedir Orçamento
            </button>
            <button
              onClick={() => handleSectionChange('calendar')}
              className={`w-full text-left px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 ${
                activeSection === 'calendar'
                  ? 'bg-yellow-400 text-black shadow-sm'
                  : 'text-amber-700 hover:text-black hover:bg-amber-50'
              }`}
            >
              Disponibilidade
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/20 z-40 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </>
  );
};

export default Header;